def greeting():
   return "Hello, I'm your first library!"